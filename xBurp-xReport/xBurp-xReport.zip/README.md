## xBurp & xReport

**xBurp** and **xReport** are lightweight Python-based BurpSuite extensions designed to automate key scanning and reporting functions. Built specifically for use with [Sec-Sci AutoPT](https://www.security-science.com/sec-sci-autopt) framework, these tools streamline the penetration testing workflow by automating security scan monitoring, exporting report, and BurpSuite shutdown.


## 🔍 Features

### ❎ xBurp
- Monitors BurpSuite's active scan status.
- Automatically closes Burp once all scans are complete.

### 📝️ xReport
- Exports Burp's scan issues in:
  - HTML format
  - XML format
  - Or both, based on user selection


## ⚙️ Prerequisites

Before installing the extension, ensure the following:

| Component       | Required | Notes                                                                                     |
|-----------------|----------|-------------------------------------------------------------------------------------------|
| BurpSuite       | ✅        | Professional version                                                                      |
| Jython          | ✅        | [Download Jython](https://www.jython.org/download) (e.g., `jython-standalone-2.7.4.jar`)  |
| Python (Jython) | ✅        | Must use Python 2.7 syntax                                                                |

## 📥 Installation Steps

### 1. Download the Jython Standalone JAR

1. Go to [https://www.jython.org/download](https://www.jython.org/download)
2. Download the **standalone jar** (e.g. `jython-standalone-2.7.4.jar`)
3. Save the file, e.g., `jython-standalone-2.7.4.jar`, to a known location.

### 2. Enable Python Support in BurpSuite

1. Open **BurpSuite**
2. Navigate to **Extender** → **Options**
3. Scroll to **Python Environment**
4. Click **Select file…**
5. Choose the download file (e.g., `jython-standalone-2.7.4.jar`)

### 3. Load the Extensions into BurpSuite

1. [Download](https://github.com/securityscience/SecSci-BurpExtenders/raw/refs/heads/main/xBurp-xReport/xBurp-xReport.rar) xBurp and xReport
   - Unzip the download .zip file
   - MD5 hash: 953d7fcb797a5d1cf6697e2af1b98415
2. Go to **Extender** → **Extensions**
3. Click **Add**
4. Set:
   - **Extension Type**: Python
   - **Extension File**: `nmap_ssl_scanner.py`
5. Click **Next** → then **Finish**
6. 
1. Go to **Extender** → **Extensions**
2. Click **Add**
3. Set Extension type to **Python**
4. Point to the `.py` file for either `xBurp.py` or `xReport.py`
5. Select the Jython JAR file as the Python Environment

---

## 🚀 Usage Instructions

### xBurp

* Load `xBurp.py` into Burp Suite
* Run active scans as usual
* xBurp will monitor the scanning queue and gracefully shut down Burp once all scans complete

### xReport

* Load `xReport.py` into Burp Suite
* Choose export format (HTML, XML, or both)
* Reports will be generated in the configured output directory upon invocation

*Note: Make sure Burp has completed scanning before using xReport for accurate results.*

---

## 🛠️ Troubleshooting

* **Extension not loading?**

  * Confirm you selected the correct Jython JAR path in Burp
  * Ensure Python code is compatible with Jython (avoid unsupported libraries)

* **Scan not detected by xBurp?**

  * Verify that the scan was initiated through Burp’s active scanner and that it appears in the scan queue

* **No output from xReport?**

  * Check that issues exist in the target scope
  * Validate write permissions for the output directory

---

## 🧩 Integration with Sec-Sci AutoPT

These extensions are designed to operate seamlessly as part of the [Sec-Sci AutoPT](https://www.security-science.com/sec-sci-autopt) automated testing pipeline. Use them in scripted penetration testing workflows to enable fully autonomous assessment cycles.

---

## 📄 License

MIT License (or insert your preferred license here)

---

## 📫 Contact

For issues, contributions, or support, please reach out via [https://www.security-science.com](https://www.security-science.com).

```

---

Would you like this README to be tailored further for GitHub formatting, or bundled into a downloadable `.zip` with example configs?
```
